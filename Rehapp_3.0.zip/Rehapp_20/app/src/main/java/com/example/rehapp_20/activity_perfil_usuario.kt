package com.example.rehapp_20

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class activity_perfil_usuario : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil_usuario)

        val txt: TextView = findViewById(R.id.modulo1RehabilitacionMuñeca)
        txt.setOnClickListener {

            val intent: Intent = Intent(this, modulo1:: class.java)
            startActivity(intent)

        }
    }
}