package com.example.rehapp_20

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class activity_registro_fisio : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_fisio)
    }
}